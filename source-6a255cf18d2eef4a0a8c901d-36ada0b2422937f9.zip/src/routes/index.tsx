import { createFileRoute, Link } from '@tanstack/react-router'
import { allStories } from 'content-collections'

export const Route = createFileRoute('/')({
  component: TableOfContents,
})

const ROMAN = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X']

function TableOfContents() {
  const stories = [...allStories].sort((a, b) => a.order - b.order)

  return (
    <div
      style={{ minHeight: '100vh', backgroundColor: 'var(--parchment)' }}
      className="relative overflow-hidden"
    >
      {/* Decorative spine line */}
      <div
        style={{
          position: 'fixed',
          left: 0,
          top: 0,
          bottom: 0,
          width: '6px',
          background: 'linear-gradient(180deg, var(--accent) 0%, var(--gold) 50%, var(--accent) 100%)',
        }}
      />

      <div className="max-w-3xl mx-auto px-8 py-20" style={{ paddingLeft: '3rem' }}>
        {/* Book header */}
        <header className="animate-fade-in mb-24 text-center">
          {/* Decorative top rule */}
          <div className="flex items-center gap-4 justify-center mb-10">
            <div style={{ height: '1px', width: '80px', backgroundColor: 'var(--rule)' }} />
            <div
              style={{
                width: '8px',
                height: '8px',
                backgroundColor: 'var(--gold)',
                transform: 'rotate(45deg)',
              }}
            />
            <div style={{ height: '1px', width: '80px', backgroundColor: 'var(--rule)' }} />
          </div>

          <p
            style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontSize: '0.85rem',
              letterSpacing: '0.35em',
              color: 'var(--ink-faded)',
              textTransform: 'uppercase',
              marginBottom: '1.5rem',
            }}
          >
            A Collection of Seven Stories
          </p>

          <h1
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: 'clamp(2.4rem, 6vw, 4rem)',
              fontWeight: '600',
              lineHeight: '1.15',
              color: 'var(--ink)',
              marginBottom: '0.75rem',
              letterSpacing: '-0.01em',
            }}
          >
            Stories at the
            <br />
            <em style={{ fontStyle: 'italic', color: 'var(--accent)' }}>Edge of Things</em>
          </h1>

          {/* Bottom rule */}
          <div className="flex items-center gap-4 justify-center mt-10">
            <div style={{ height: '1px', width: '120px', backgroundColor: 'var(--rule)' }} />
            <div style={{ height: '1px', width: '120px', backgroundColor: 'var(--rule)' }} />
          </div>
        </header>

        {/* Table of Contents label */}
        <div className="animate-slide-up animate-delay-2 mb-10">
          <p
            style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontSize: '0.8rem',
              letterSpacing: '0.4em',
              color: 'var(--ink-faded)',
              textTransform: 'uppercase',
              textAlign: 'center',
            }}
          >
            Contents
          </p>
        </div>

        {/* Story list */}
        <ol style={{ listStyle: 'none', padding: 0, margin: 0 }}>
          {stories.map((story, i) => (
            <li
              key={story.slug}
              className={`animate-slide-up animate-delay-${i + 2}`}
              style={{ marginBottom: '0' }}
            >
              <Link
                to="/stories/$slug"
                params={{ slug: story.slug }}
                style={{ textDecoration: 'none', display: 'block' }}
              >
                <div
                  className="group"
                  style={{
                    display: 'flex',
                    alignItems: 'baseline',
                    gap: '1.5rem',
                    padding: '1.5rem 1rem',
                    borderBottom: '1px solid var(--rule-light)',
                    transition: 'all 0.25s ease',
                    cursor: 'pointer',
                    position: 'relative',
                  }}
                  onMouseEnter={e => {
                    const el = e.currentTarget as HTMLElement
                    el.style.backgroundColor = 'rgba(139,58,42,0.04)'
                    el.style.paddingLeft = '1.5rem'
                  }}
                  onMouseLeave={e => {
                    const el = e.currentTarget as HTMLElement
                    el.style.backgroundColor = 'transparent'
                    el.style.paddingLeft = '1rem'
                  }}
                >
                  {/* Roman numeral */}
                  <span
                    style={{
                      fontFamily: "'Cormorant Garamond', serif",
                      fontSize: '0.9rem',
                      fontWeight: '300',
                      color: 'var(--accent)',
                      letterSpacing: '0.05em',
                      minWidth: '2rem',
                      textAlign: 'right',
                      flexShrink: 0,
                    }}
                  >
                    {ROMAN[i]}
                  </span>

                  {/* Dot leaders */}
                  <div
                    style={{
                      flex: 1,
                      borderBottom: '1px dotted var(--rule)',
                      marginBottom: '0.35rem',
                      opacity: 0.5,
                    }}
                  />

                  {/* Title and meta */}
                  <div style={{ textAlign: 'right', flexShrink: 0, maxWidth: '60%' }}>
                    <div
                      style={{
                        fontFamily: "'Playfair Display', serif",
                        fontSize: '1.2rem',
                        fontWeight: '500',
                        color: 'var(--ink)',
                        lineHeight: '1.3',
                        transition: 'color 0.2s',
                      }}
                    >
                      {story.title}
                    </div>
                    <div
                      style={{
                        fontFamily: "'Cormorant Garamond', serif",
                        fontSize: '0.82rem',
                        color: 'var(--ink-faded)',
                        fontStyle: 'italic',
                        marginTop: '0.25rem',
                        letterSpacing: '0.02em',
                      }}
                    >
                      {story.genre}
                    </div>
                  </div>
                </div>

                {/* Summary — revealed on hover via inline approach */}
                <div
                  style={{
                    padding: '0 1rem 1.25rem',
                    marginTop: '-0.25rem',
                    display: 'none',
                  }}
                />
              </Link>
            </li>
          ))}
        </ol>

        {/* Footer epigraph */}
        <footer className="animate-slide-up animate-delay-8 mt-24 text-center">
          <div className="flex items-center gap-4 justify-center mb-6">
            <div style={{ height: '1px', width: '60px', backgroundColor: 'var(--rule)' }} />
            <div
              style={{
                width: '6px',
                height: '6px',
                backgroundColor: 'var(--gold)',
                transform: 'rotate(45deg)',
              }}
            />
            <div style={{ height: '1px', width: '60px', backgroundColor: 'var(--rule)' }} />
          </div>
          <p
            style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontSize: '1rem',
              fontStyle: 'italic',
              color: 'var(--ink-faded)',
              maxWidth: '28rem',
              margin: '0 auto',
              lineHeight: '1.7',
            }}
          >
            "Every short story is an act of faith —
            <br />
            a bet that a small thing can hold a large one."
          </p>
        </footer>
      </div>
    </div>
  )
}
