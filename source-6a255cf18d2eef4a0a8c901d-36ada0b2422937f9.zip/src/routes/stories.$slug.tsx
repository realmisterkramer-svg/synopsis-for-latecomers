import { createFileRoute, Link } from '@tanstack/react-router'
import { marked } from 'marked'
import { allStories } from 'content-collections'

export const Route = createFileRoute('/stories/$slug')({
  loader: async ({ params }) => {
    const sorted = [...allStories].sort((a, b) => a.order - b.order)
    const idx = sorted.findIndex((s) => s.slug === params.slug)
    if (idx === -1) throw new Error('Story not found')
    return {
      story: sorted[idx],
      prev: idx > 0 ? sorted[idx - 1] : null,
      next: idx < sorted.length - 1 ? sorted[idx + 1] : null,
      total: sorted.length,
    }
  },
  component: StoryReader,
  head: ({ loaderData }) => ({
    meta: loaderData
      ? [
          { title: `${loaderData.story.title} — Stories at the Edge of Things` },
          { name: 'description', content: loaderData.story.summary },
        ]
      : [],
  }),
})

const ROMAN = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X']

function StoryReader() {
  const { story, prev, next, total } = Route.useLoaderData()
  const html = marked(story.content) as string
  const orderLabel = ROMAN[story.order - 1] ?? String(story.order)

  return (
    <div style={{ minHeight: '100vh', backgroundColor: 'var(--parchment)' }}>
      {/* Top navigation bar */}
      <nav
        style={{
          position: 'sticky',
          top: 0,
          zIndex: 100,
          backgroundColor: 'var(--parchment)',
          borderBottom: '1px solid var(--rule-light)',
          padding: '0.875rem 2rem',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          backdropFilter: 'blur(4px)',
        }}
      >
        {/* Back to contents */}
        <Link
          to="/"
          style={{
            fontFamily: "'Cormorant Garamond', serif",
            fontSize: '0.85rem',
            letterSpacing: '0.15em',
            color: 'var(--ink-faded)',
            textDecoration: 'none',
            textTransform: 'uppercase',
            display: 'flex',
            alignItems: 'center',
            gap: '0.5rem',
            transition: 'color 0.2s',
          }}
          onMouseEnter={e => ((e.currentTarget as HTMLElement).style.color = 'var(--accent)')}
          onMouseLeave={e => ((e.currentTarget as HTMLElement).style.color = 'var(--ink-faded)')}
        >
          <svg width="14" height="10" viewBox="0 0 14 10" fill="none">
            <path d="M5 1L1 5L5 9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            <line x1="1" y1="5" x2="13" y2="5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
          </svg>
          Contents
        </Link>

        {/* Position indicator */}
        <div
          style={{
            fontFamily: "'Cormorant Garamond', serif",
            fontSize: '0.82rem',
            color: 'var(--ink-faded)',
            letterSpacing: '0.1em',
            fontStyle: 'italic',
          }}
        >
          Story {story.order} of {total}
        </div>

        {/* Prev / Next */}
        <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
          {prev ? (
            <Link
              to="/stories/$slug"
              params={{ slug: prev.slug }}
              title={prev.title}
              style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontSize: '0.85rem',
                letterSpacing: '0.15em',
                color: 'var(--ink-faded)',
                textDecoration: 'none',
                textTransform: 'uppercase',
                display: 'flex',
                alignItems: 'center',
                gap: '0.4rem',
                transition: 'color 0.2s',
              }}
              onMouseEnter={e => ((e.currentTarget as HTMLElement).style.color = 'var(--accent)')}
              onMouseLeave={e => ((e.currentTarget as HTMLElement).style.color = 'var(--ink-faded)')}
            >
              <svg width="14" height="10" viewBox="0 0 14 10" fill="none">
                <path d="M5 1L1 5L5 9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                <line x1="1" y1="5" x2="13" y2="5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
              </svg>
              Prev
            </Link>
          ) : (
            <span style={{ width: '3.5rem' }} />
          )}

          {next ? (
            <Link
              to="/stories/$slug"
              params={{ slug: next.slug }}
              title={next.title}
              style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontSize: '0.85rem',
                letterSpacing: '0.15em',
                color: 'var(--ink-faded)',
                textDecoration: 'none',
                textTransform: 'uppercase',
                display: 'flex',
                alignItems: 'center',
                gap: '0.4rem',
                transition: 'color 0.2s',
              }}
              onMouseEnter={e => ((e.currentTarget as HTMLElement).style.color = 'var(--accent)')}
              onMouseLeave={e => ((e.currentTarget as HTMLElement).style.color = 'var(--ink-faded)')}
            >
              Next
              <svg width="14" height="10" viewBox="0 0 14 10" fill="none">
                <path d="M9 1L13 5L9 9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                <line x1="13" y1="5" x2="1" y2="5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/>
              </svg>
            </Link>
          ) : (
            <span style={{ width: '3.5rem' }} />
          )}
        </div>
      </nav>

      {/* Story content */}
      <article className="animate-fade-in" style={{ maxWidth: '680px', margin: '0 auto', padding: '4rem 2rem 6rem' }}>

        {/* Chapter heading */}
        <header style={{ textAlign: 'center', marginBottom: '3.5rem' }}>
          <div className="flex items-center gap-4 justify-center mb-8">
            <div style={{ height: '1px', flex: 1, maxWidth: '80px', backgroundColor: 'var(--rule)' }} />
            <p
              style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontSize: '0.8rem',
                letterSpacing: '0.4em',
                color: 'var(--accent)',
                textTransform: 'uppercase',
                margin: 0,
              }}
            >
              {orderLabel}
            </p>
            <div style={{ height: '1px', flex: 1, maxWidth: '80px', backgroundColor: 'var(--rule)' }} />
          </div>

          <h1
            style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: 'clamp(1.8rem, 5vw, 2.8rem)',
              fontWeight: '600',
              color: 'var(--ink)',
              lineHeight: '1.2',
              letterSpacing: '-0.01em',
              marginBottom: '1.25rem',
            }}
          >
            {story.title}
          </h1>

          <p
            style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontSize: '1rem',
              fontStyle: 'italic',
              color: 'var(--ink-faded)',
              lineHeight: '1.6',
              maxWidth: '36rem',
              margin: '0 auto 0.75rem',
            }}
          >
            {story.summary}
          </p>

          <p
            style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontSize: '0.78rem',
              letterSpacing: '0.3em',
              color: 'var(--rule)',
              textTransform: 'uppercase',
            }}
          >
            {story.genre}
          </p>

          {/* Decorative rule */}
          <div style={{ marginTop: '2.5rem', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '1rem' }}>
            <div style={{ height: '1px', width: '40px', backgroundColor: 'var(--rule)' }} />
            <div style={{ width: '5px', height: '5px', backgroundColor: 'var(--gold)', transform: 'rotate(45deg)' }} />
            <div style={{ height: '1px', width: '40px', backgroundColor: 'var(--rule)' }} />
          </div>
        </header>

        {/* Body text */}
        <div
          className="prose-story"
          dangerouslySetInnerHTML={{ __html: html }}
        />

        {/* End mark */}
        <div style={{ textAlign: 'center', marginTop: '3rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '1rem' }}>
            <div style={{ height: '1px', width: '60px', backgroundColor: 'var(--rule)' }} />
            <div
              style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontSize: '1.4rem',
                color: 'var(--accent)',
                lineHeight: 1,
              }}
            >
              ✦
            </div>
            <div style={{ height: '1px', width: '60px', backgroundColor: 'var(--rule)' }} />
          </div>
        </div>
      </article>

      {/* Bottom navigation */}
      <footer
        style={{
          borderTop: '1px solid var(--rule-light)',
          backgroundColor: 'var(--parchment-dark)',
          padding: '2.5rem 2rem',
        }}
      >
        <div
          style={{
            maxWidth: '680px',
            margin: '0 auto',
            display: 'grid',
            gridTemplateColumns: '1fr auto 1fr',
            alignItems: 'center',
            gap: '1rem',
          }}
        >
          {/* Prev story */}
          <div>
            {prev && (
              <Link
                to="/stories/$slug"
                params={{ slug: prev.slug }}
                style={{ textDecoration: 'none', display: 'block' }}
              >
                <div
                  style={{ padding: '1rem 1.25rem', border: '1px solid var(--rule-light)', transition: 'all 0.2s', cursor: 'pointer' }}
                  onMouseEnter={e => {
                    (e.currentTarget as HTMLElement).style.borderColor = 'var(--accent)'
                    ;(e.currentTarget as HTMLElement).style.backgroundColor = 'rgba(139,58,42,0.04)'
                  }}
                  onMouseLeave={e => {
                    (e.currentTarget as HTMLElement).style.borderColor = 'var(--rule-light)'
                    ;(e.currentTarget as HTMLElement).style.backgroundColor = 'transparent'
                  }}
                >
                  <p style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '0.72rem', letterSpacing: '0.3em', color: 'var(--ink-faded)', textTransform: 'uppercase', margin: '0 0 0.4rem' }}>
                    ← Previous
                  </p>
                  <p style={{ fontFamily: "'Playfair Display', serif", fontSize: '1rem', color: 'var(--ink)', margin: 0, lineHeight: 1.3 }}>
                    {prev.title}
                  </p>
                </div>
              </Link>
            )}
          </div>

          {/* Back to contents center */}
          <Link
            to="/"
            style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: '0.4rem',
              textDecoration: 'none',
              padding: '0.5rem',
            }}
          >
            <div
              style={{ width: '32px', height: '32px', border: '1px solid var(--rule)', display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'all 0.2s' }}
              onMouseEnter={e => {
                (e.currentTarget as HTMLElement).style.borderColor = 'var(--accent)'
                ;(e.currentTarget as HTMLElement).style.backgroundColor = 'rgba(139,58,42,0.06)'
              }}
              onMouseLeave={e => {
                (e.currentTarget as HTMLElement).style.borderColor = 'var(--rule)'
                ;(e.currentTarget as HTMLElement).style.backgroundColor = 'transparent'
              }}
            >
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                <rect x="1" y="1" width="5" height="5" stroke="var(--ink-faded)" strokeWidth="1.2"/>
                <rect x="8" y="1" width="5" height="5" stroke="var(--ink-faded)" strokeWidth="1.2"/>
                <rect x="1" y="8" width="5" height="5" stroke="var(--ink-faded)" strokeWidth="1.2"/>
                <rect x="8" y="8" width="5" height="5" stroke="var(--ink-faded)" strokeWidth="1.2"/>
              </svg>
            </div>
            <span style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '0.72rem', letterSpacing: '0.2em', color: 'var(--ink-faded)', textTransform: 'uppercase' }}>
              Contents
            </span>
          </Link>

          {/* Next story */}
          <div style={{ textAlign: 'right' }}>
            {next && (
              <Link
                to="/stories/$slug"
                params={{ slug: next.slug }}
                style={{ textDecoration: 'none', display: 'block' }}
              >
                <div
                  style={{ padding: '1rem 1.25rem', border: '1px solid var(--rule-light)', transition: 'all 0.2s', cursor: 'pointer' }}
                  onMouseEnter={e => {
                    (e.currentTarget as HTMLElement).style.borderColor = 'var(--accent)'
                    ;(e.currentTarget as HTMLElement).style.backgroundColor = 'rgba(139,58,42,0.04)'
                  }}
                  onMouseLeave={e => {
                    (e.currentTarget as HTMLElement).style.borderColor = 'var(--rule-light)'
                    ;(e.currentTarget as HTMLElement).style.backgroundColor = 'transparent'
                  }}
                >
                  <p style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '0.72rem', letterSpacing: '0.3em', color: 'var(--ink-faded)', textTransform: 'uppercase', margin: '0 0 0.4rem' }}>
                    Next →
                  </p>
                  <p style={{ fontFamily: "'Playfair Display', serif", fontSize: '1rem', color: 'var(--ink)', margin: 0, lineHeight: 1.3 }}>
                    {next.title}
                  </p>
                </div>
              </Link>
            )}
          </div>
        </div>
      </footer>
    </div>
  )
}
