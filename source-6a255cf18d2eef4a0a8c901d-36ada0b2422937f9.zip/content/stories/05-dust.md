---
title: "Dust"
summary: "The last colonist on an abandoned Mars outpost records a farewell transmission into the void. The void answers."
genre: "Science Fiction"
order: 5
---

**TRANSMISSION LOG — EREBUS STATION, OLYMPUS RIM**
*Day 847 of unplanned solo occupation*
*Operator: Solis, E. (Dr.), Geochemistry*

I am recording this because that is what I do. I have recorded something every day for eight hundred and forty-seven days. I will not change that now.

The oxygen situation is as follows: the primary electrolyzer has been non-functional since Day 791. The secondary failed on Day 839. I have been living on reserve tanks. There are enough for approximately nine days. Rescue is not coming in nine days. The evacuation ship that was supposed to arrive in March of last year did not arrive, and the subsequent ships have not arrived, and I have stopped trying to understand why and started trying to use the time well.

I have finished my research. All sixteen ongoing studies are complete. I have written the reports. I have transmitted them to Earth orbit, though I cannot confirm receipt.

I have also done the following: read everything in the station library, including the ship manifests and the engineering manuals and the collection of poetry that Dr. Anand left behind when she evacuated on Day 12. I have learned to bake bread using the hydroponics grain stores, with uneven results. I have maintained a log of the dust storms, which have been remarkable this season. I have done a great deal of thinking about impermanence.

The dust here is not like Earth dust. It is finer and older and carries iron in ratios that, when I analyze the spectrometry, read like a sentence written in a language I can almost understand. I have said this in my formal reports and removed it, because it sounds like the sort of thing you say when you have been alone for eight hundred and forty-seven days.

But I believe it.

I am transmitting this into the relay on the chance that someone receives it. If you receive it: I am well. I have been well. The work is done and the bread has gotten better. I am not afraid in the way I expected to be afraid. I am mostly grateful for the dust and the way it moves in the low light just before dawn, which on Mars is a color you would not believe.

If no one receives this: I am speaking to the planet. I don't think it listens, but I have been talking to it for eight hundred and forty-seven days and something is listening. Maybe it is only me.

End transmission.

---

*Day 849*

Something has happened.

Yesterday I received a transmission. It came through the emergency relay band, which I thought was broken. It was not broken.

The message was six words: *We are coming. Hold on, Elan.*

I do not know who sent it. The relay does not record origin points. I have analyzed the signal and it is consistent with an orbital source, which means a ship, which means someone is close enough to see us.

I am going to make bread.

I am going to keep the lights on.

I am going to sit in the forward dome and watch the dust move in the light before dawn, which is a color — I want to say this clearly, for the record — a color worth coming back to.

End transmission.
