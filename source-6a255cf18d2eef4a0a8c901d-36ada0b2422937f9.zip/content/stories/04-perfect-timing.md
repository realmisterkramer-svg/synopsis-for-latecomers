---
title: "Perfect Timing"
summary: "For three years, they missed each other by minutes at the same coffee shop. Then Tuesday happened differently."
genre: "Romance"
order: 4
---

The barista's name was Preet and she had, over the course of three years, compiled a mental file on the two of them without meaning to.

The man came in at 8:14 every weekday, give or take two minutes. He ordered a double espresso and whatever savory pastry was closest to the register, paid without looking at the total, and read physical newspapers — *plural*, he bought two — while standing at the counter rather than sitting, which Preet found eccentric and endearing. He left by 8:35.

The woman came in at 8:37 every weekday, give or take four minutes. She ordered a pour-over and the same almond croissant every time regardless of what was actually available that day — she would wait for Preet to make it fresh if they were out, which they often were — and she worked on her laptop at the table by the window and left between 9:30 and 9:45.

For three years, their paths did not cross in the shop. They were ships that passed in a two-minute window. Preet had thought once, in a slow afternoon moment, that it was the saddest thing she had ever witnessed, though she couldn't have explained to anyone why she thought of it as sad. They were strangers. There was no story.

On a Tuesday in October, the man arrived late.

8:38. Preet saw him come through the door and the woman was still at the window table and felt something she later described to her partner as the sensation of watching a plate fall in slow motion.

He went to the counter. He looked at the pastry case. He ordered his espresso. He reached for the newspapers.

The woman looked up from her laptop.

She said, from across the shop: *Those are from yesterday.*

He said: *I beg your pardon?*

*The papers. They're dated yesterday. Preet must not have swapped them yet.*

Preet had, in fact, forgotten to swap them. This was not her finest moment.

The man looked at the papers. He looked at the woman. He said: *How do you know what day the papers are from?*

She said: *I come here every day.*

He said: *I come here every day.*

There was a pause of the particular kind that Preet recognized from years of retail: the pause that precedes either a conversation or its deliberate avoidance.

He said: *I've never seen you.*

She said: *I arrive at 8:37.*

He said, slowly: *I leave at 8:35.*

The woman looked at him. The man looked at the papers. Preet busied herself with the espresso machine.

He said: *Two minutes.*

She said: *For three years.*

He put the newspapers down. He picked up his espresso. He looked at the table by the window and then at the woman and then at the chair across from her, which was empty, as it was every day, as it had been for three years.

He said: *Is that seat taken?*

She said: *Not as far as I can tell.*

Preet served them both without comment. This was her professional gift: the understanding that some moments were not improved by testimony.

They stayed until 10:15. When they left, they left together.

Preet swapped out the newspapers and thought: three years is a long time to miss someone. Two minutes is barely any time at all.

She wrote both of these things in the small notebook she kept under the register, where she noted things she wanted to remember. She did not write anything else about them. It seemed sufficient.
