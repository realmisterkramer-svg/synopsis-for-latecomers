---
title: "What the River Knows"
summary: "The Erlan River has always remembered the drowned. This autumn, it begins to speak."
genre: "Magical Realism"
order: 7
---

The first person to hear it was a boy named Caspar who was twelve and fishing where he was not supposed to be.

The voice came from the water — not from beneath it, but from the movement of it, the way the current folded against the east bank stones. He could not make out the words at first, only the rhythm, which was the rhythm of a sentence. He leaned closer and the water said, in the voice of a woman he did not recognize: *I left the door unlocked. He never came back.*

Caspar dropped his line.

He told his mother, who told her sister, who told the priest, who said that boys who fished where they were not supposed to be had overactive imaginations. The priest was not wrong about the boy in general, but he was wrong about this.

The river was called the Erlan, and it ran through the town of Veld on its way to somewhere larger, which it reached without fanfare. The Erlan was not a dramatic river. It was the color of iron in autumn, shallow enough to wade across in summer, and it flooded sometimes but not violently. The town of Veld had lived beside it for three hundred years. In that time, seventeen people had drowned in the Erlan, which was fewer than you'd expect, and each of them was remembered in the way that small towns remember things: thoroughly, and with a selectiveness that over generations became its own kind of truth.

The river remembered differently.

It remembered the seventeen, but it also remembered what they had been thinking. It remembered the door the woman had left unlocked for a man who didn't return — she was the third drowning, 1923, a cold March. It remembered the boy in 1961 who had gone into the water because of a bet and who, at the moment the current took him, had been thinking about a particular green field he'd walked through once and never found again. It remembered the old ferryman from 1888 who had thought, very clearly, *well, that's that.*

No one knew why the river began to speak in October of this particular year. Some said it was the drought, which had lowered the water table and brought the river into contact with older sediment, older memories. Some said it was simply time — that everything that has witnessed enough eventually runs out of silence.

The townsfolk came in careful groups. They stood at the bank and listened. The river gave them pieces: *I wanted to tell her. I never found the words.* And: *The light on that morning was extraordinary, I remember the light.* And once, from a stretch near the old mill: *Does anyone still know where I put it?*

They did not always know whose voice they were hearing. Sometimes they recognized the cadences of grandparents, the particular way a dead relative had formed a sentence. Sometimes the voices were entirely unfamiliar, belonging to lives the town had forgotten it had swallowed.

Caspar, who had started all of this, came back to the east bank on a Saturday in November and sat for a long time. The river was quiet that day — the cold had settled it, brought it close to its winter murmur.

Then, very faintly, in a voice that sounded like no one he knew: *I was here. I was here for a long time.*

The boy said, to the water: *I know. We know.*

The river moved past him toward the sea, carrying its long memory.

He did not know if it heard him. But the saying of it seemed important.

He picked up his line and cast it, where he was not supposed to be, into the river that remembered everything.
