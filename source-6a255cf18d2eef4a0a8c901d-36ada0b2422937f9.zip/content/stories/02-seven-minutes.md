---
title: "Seven Minutes"
summary: "A surgeon has seven minutes to evacuate the ICU before the fire reaches it. She has eight patients she cannot move."
genre: "Thriller"
order: 2
---

The call came at 3:17 a.m. and Dr. Voss was already awake because the night shift never really ended, just changed its texture. The fire was in the east stairwell, three floors below the ICU, and the evacuation alarm had seized the building in its red-and-white teeth.

Seven minutes, the fire marshal said over the radio. Maybe eight.

She had eight patients in the ICU who could not be moved.

Voss stood in the doorway of the unit and felt something she later could not name — not calm, but a cousin of calm, the state that lives just past panic when the body decides that panic is no longer useful. She turned to Nurse Delacroix and said: *Close all the doors. Roll the crash carts to the windows. Get everyone who can walk into the hallway.*

Delacroix said: *What about the ones who can't?*

*That's what I'm going to think about in the next six minutes.*

The patients: two post-surgical, one with a tracheotomy, three on ventilators, one elderly man in a coma she privately thought of as resting rather than unconscious, and one seventeen-year-old boy who had been transferred from pediatrics two days ago and whose name was Felix and who had asked her once what she thought happened after.

She moved through the ward. Checked the seals on the ventilator tubes. Looked at the window and calculated the distance to the courtyard and the likely trajectory of smoke. Checked the oxygen feeds — fully charged, six hours of reserve. The fire, if it took the stairwell, would likely bypass the sealed corridor. Likely.

At four minutes she radioed the ground floor and told them she needed hoses at the corridor junction, east wall.

At three minutes she pulled a chair to Felix's bedside. He was awake. He looked at her face and seemed to understand that something was happening that adults were trying to handle, and that this was not reassuring.

He said: *Is it bad?*

She said: *It's manageable.* Which was not quite a lie — it was the category she intended to put it in.

He said: *What do I do?*

She had not been asked that before. She thought about it.

*You breathe normally,* she said. *You let the machines do what they're doing. You trust that they were built by people who thought about exactly this situation.*

*Did they?*

She looked at the ventilator. She thought of whoever had designed the battery backup, the sealed housing, the fireproof cable sheathing. She thought of all the engineers who had asked themselves, *but what if*.

*Yes,* she said. *They did.*

At one minute she stood in the center of the ward and looked at her eight patients and the closed doors and the sealed ventilators and the fire that was somewhere below her in the dark building, working through its fuel.

She picked up the radio.

*ICU is sealed and holding,* she said. *Eight patients, stable. We are not evacuating. I need suppression at junction E-7.*

There was a pause on the other end. Then: *Confirmed, doctor.*

The smoke never reached them. The hoses reached the junction at E-7 in time, and the fire found nothing to eat in the sealed corridor, and at 4:08 a.m. the building was declared safe and Voss walked outside into air that tasted clean and expensive.

Felix was transferred to a regular room three days later.

On his last day, he asked her again what she thought happened after.

She said: *I think it depends a lot on what you do before.*

He seemed to find this adequate.
