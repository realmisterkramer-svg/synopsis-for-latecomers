---
title: "The Weight of Small Things"
summary: "On her last afternoon, a woman moves through her house giving things away. Each object is a sentence in a longer story."
genre: "Literary Fiction"
order: 6
---

The blue pitcher went to Dolores.

Ines had known Dolores for fifty-one years, had attended her two weddings and her one funeral and had sat with her through the long winter of 1987 when everything had been difficult and neither of them had spoken about it directly, which was the only way to survive certain things. Dolores had always admired the blue pitcher. It had come from Portugal, from a market where Ines had been briefly, completely happy — the kind of happiness that has no cause, that simply descends like weather.

She wrapped the pitcher in tissue paper and set it inside the door.

The green coat — the one she'd worn in Paris in 1971, which no longer fit and had not fit for forty years — she could not give away. She folded it and put it in the cedar chest with the photographs and the two letters she had kept and the dried flower from a wedding that was not hers, from a day she had stood in a garden in September and felt that the world was large and would accommodate her.

She gave the books to her son Martin, who would not read them but would keep them on the same shelf until he died, and she found this sufficient.

She gave the kitchen table to her neighbor, who had a family and needed a table that could seat eight. The neighbor cried when she learned why. Ines said: *Don't. It's just a table.* But it was not just a table, and they both knew this, and the honesty of the fiction was a kindness they offered each other.

She kept the small things. The button from a coat she no longer had. The river stone that fit exactly in the palm. The folded piece of paper with a joke her husband had written down once, years ago, that she had never entirely understood but had laughed at because his face while telling it was worth the uncertainty.

By late afternoon she had moved through the whole house and it was lighter. Not empty — she had not given everything — but lighter in the way a room is lighter when you open the right window.

She sat in the chair by the front window with the river stone in her hand and watched the street. A child was riding a bicycle with tremendous concentration. A car she didn't recognize drove slowly past, looking for an address. The neighbor's dog crossed the yard and stopped and looked at her and then continued.

The light changed in the particular way it does at five o'clock in autumn, going gold and then amber and then something that has no name, a color that exists only on its way to the dark.

She thought about Portugal. About the market and the blue pitcher and the kind of happiness that has no cause. She thought about the garden in September. She thought about the joke she had never quite understood.

She thought: *I have had a very long time. And the time was full.*

She put the river stone in her pocket.

This is what she kept: the button, the stone, the folded paper, the cedar chest with the coat she couldn't give up.

These were small things. But small things, she had learned, have their own gravity — the way they orbit you, the way you orbit them, the long patient pull of them across a life.

Dolores came for the pitcher at six o'clock, and they had tea, and did not talk about it.

Outside, the light had finished its change.
