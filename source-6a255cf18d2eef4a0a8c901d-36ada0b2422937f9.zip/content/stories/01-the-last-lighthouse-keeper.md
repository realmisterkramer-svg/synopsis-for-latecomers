---
title: "The Last Lighthouse Keeper"
summary: "On an island with no name, a keeper tends a light no ship needs — until something answers back."
genre: "Literary Fiction"
order: 1
---

The light had not saved a ship in thirty-one years.

Harlan knew this because he kept a ledger — not of rescues, which had stopped long before he arrived, but of storms. Each entry was the same: *date, wind speed, hours of fog, ships sighted: zero.* He filled the columns with a careful hand, and when the book was full, he started a new one. This was his inheritance: the duty of attention with no one to receive it.

The island had no name on any map made after 1952. Before that, it appeared as a black dot labeled *Cairn Spit*, though there was no cairn and the ground was granite, not gravel. Harlan had come here because the posting paid above the rate and because he had nowhere particular else to be. That was fifteen years ago. He was fifty-four now, and his hair had gone the color of the rock.

He found the bottle on a Tuesday morning in March, wedged between two boulders at the base of the eastern cliff. It was green glass, thick-shouldered, sealed with a wax plug he had to chip away with a penknife. The paper inside was dry. This was impossible — the bottle had been sitting in the spray — but the paper was dry.

*Is anyone there?*

That was all. Three words in handwriting that leaned to the left, as if bracing against wind.

Harlan stood with the paper for a long time. The light revolved behind him without caring. He read the words again. He turned the paper over and found the back blank, and then he read the front again.

He did not write back immediately. This surprised him, because he was not a man who delayed things. He put the paper on his table and ate his lunch and walked the perimeter of the island — the same walk he took every afternoon, forty minutes, his boots worn to the exact shape of the path.

That night he sat at his table with a lantern and a clean sheet of paper.

He wrote: *Yes.*

Then he stopped. He thought about what it meant to answer a question from the sea. He thought about the handwriting, the leftward lean of it. He thought about whoever had stood at a shore somewhere and put those three words into a bottle and thrown it out into the dark, not knowing if it would reach anyone, not knowing if the bottle would sink, not knowing if there was anyone left in the world who checked.

He added a second line: *I have been here fifteen years. I keep a light. I am not sure what for, but I keep it.*

He read this back. It seemed to say something more than he intended. He folded the paper and put it in a bottle — he kept several, for reasons he had never examined — and sealed it and carried it to the eastern cliff in the dark.

He stood there a moment with the bottle in his hand and the light revolving above him, and felt, for the first time in a very long while, that the light might be for something after all.

He threw the bottle as far as he could and listened to the splash he couldn't see.

He went back inside and wrote in his ledger: *Ships sighted: none. Light kept.*

In the morning, there was a new bottle at the base of the cliff.
