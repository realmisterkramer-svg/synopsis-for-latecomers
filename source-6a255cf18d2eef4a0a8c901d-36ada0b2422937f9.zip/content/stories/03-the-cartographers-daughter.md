---
title: "The Cartographer's Daughter"
summary: "Her father's maps showed lands that did not exist. She is beginning to suspect they do not exist yet."
genre: "Fantasy"
order: 3
---

The maps smelled of something Mira could not identify: not ink, though there was ink, and not paper, though there was paper. Something older than both. She had grown up with the smell and thought of it simply as the smell of her father's study, the way other children might think of pipe smoke or beeswax.

He died in the winter she turned nineteen and left her the study and the maps and a letter that said: *Do not try to find them. Let them find you.*

She understood the last part least.

There were forty-seven maps. She had catalogued them in school — geography had been her best subject, which her father said was natural — and she had noted early on that many of the lands depicted did not correspond to any coast or country she could verify. She had assumed they were historical: territories that had been renamed, coastlines that had eroded. Her father had never explained them. He had watched her study them with an expression she now, in memory, recognized as something between pride and guilt.

She began with the smallest map: a single island, eight inches by six, with a harbor shaped like a cupped hand. The island was labeled *Cairn Spit* and the map included a lighthouse at the eastern point.

She searched every chart she could access. Cairn Spit did not exist.

The second map showed a city built across three hills, with a river that divided and reunited three times before reaching the sea. She could tell from the architecture — the dome shapes, the narrow arcades — that it belonged to no tradition she recognized, a synthesis that had no parent culture. The city was labeled *Verentum* and had a population noted in the margin: *~340,000.*

She would not find it, her father had said.

But the letter also said: *Let them find you.*

She was examining the thirty-first map when she noticed the change. It was a map she had looked at dozens of times — a mountain range with a single pass, a village at the base labeled *Ardha's Ford.* The pass was marked with a symbol she had always assumed indicated altitude: a small triangle.

Today the triangle was different. The peak of it pointed east, not north.

She got out her original notes. The triangle had been pointing north.

She checked the other maps. Three more had changed: a river had a new tributary, a city had gained a new district, a coastline had shifted imperceptibly south.

She sat with this for a long time.

There were places in the world where the maps preceded the territory — where surveyors charted new land and the land, in some sense, complied. She had read about this. She had thought it was metaphor.

She opened her father's letter again. She read the last line for the hundredth time: *Do not try to find them. Let them find you.*

She thought about what it meant for a place to find a person. She thought about the lighthouse on Cairn Spit and whoever kept it. She thought about Verentum and its 340,000 inhabitants who did not yet exist, or who existed somewhere else, in another arrangement of causes and consequences.

She opened the notebook she used for her own work and wrote at the top of a clean page: *Observation log — map changes, begin date unknown.*

Then she drew, very carefully, from memory, a map of the street she had grown up on. She labeled her father's house. She labeled the study. She left the compass rose off and thought about which way to point it.

In the morning, the notebook had a second page she had not written.
